#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Telegram bot for building the local Theos FPS project.

Security:
- Never hard-code the Telegram bot token.
- Set BOT_TOKEN in the environment.
- Only the configured Telegram username(s) may run build commands.
"""

import html
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path

import telebot
from telebot import types

BASE_DIR = Path(__file__).resolve().parent
SOURCE_FILE = BASE_DIR / "FPSDisplay.m"
BACKUP_FILE = BASE_DIR / "FPSDisplay_backup.m"
MAKEFILE = BASE_DIR / "Makefile"

ADMIN_USERNAMES = {
    name.strip().lstrip("@").lower()
    for name in os.getenv("ADMIN_USERNAMES", "vantrung23128").split(",")
    if name.strip()
}

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError(
        "Thiếu BOT_TOKEN. Hãy đặt biến môi trường BOT_TOKEN trước khi chạy bot."
    )

bot = telebot.TeleBot(TOKEN, parse_mode="HTML")
build_lock = threading.Lock()


def is_admin(message):
    username = (message.from_user.username or "").lower()
    return username in ADMIN_USERNAMES


def deny(message):
    bot.reply_to(
        message,
        "⛔ <b>Không có quyền</b>\n\n"
        "Bot build chỉ dành cho admin được cấu hình.",
    )


def project_check():
    missing = [str(p.name) for p in (SOURCE_FILE, MAKEFILE) if not p.is_file()]
    if missing:
        raise FileNotFoundError(
            "Thiếu file trong project: " + ", ".join(missing)
        )


def safe_fps_name(value):
    value = value.strip()
    if not value:
        raise ValueError("Tên FPS không được để trống.")
    if len(value) > 40:
        raise ValueError("Tên FPS tối đa 40 ký tự.")
    if any(ord(c) < 32 for c in value):
        raise ValueError("Tên FPS chứa ký tự không hợp lệ.")
    return value


def backup_source():
    shutil.copy2(SOURCE_FILE, BACKUP_FILE)


def restore_source():
    if BACKUP_FILE.is_file():
        shutil.copy2(BACKUP_FILE, SOURCE_FILE)


def modify_source(fps_name):
    content = SOURCE_FILE.read_text(encoding="utf-8")

    # Match the text passed to stringWithFormat without depending on one exact spacing style.
    pattern = re.compile(
        r'(NSString\s*\*\s*WMText\s*=\s*\[NSString\s+stringWithFormat:@")'
        r'([^"\\]*(?:\\.[^"\\]*)*)'
        r'(")'
    )

    match = pattern.search(content)
    if not match:
        # Fallback for the original source used by this project.
        old = 'Hello World '
        if old not in content:
            raise ValueError("Không tìm thấy chuỗi WMText trong FPSDisplay.m.")
        new_content = content.replace(old, fps_name.replace("\\", "\\\\").replace('"', '\\"'), 1)
    else:
        fmt = match.group(2)
        # Preserve the existing format prefix and replace only the custom suffix.
        if "Hello World" in fmt:
            new_fmt = fmt.replace("Hello World ", fps_name)
        else:
            new_fmt = re.sub(r'\s*[^%]*$', " " + fps_name, fmt)
        new_content = content[:match.start(2)] + new_fmt + content[match.end(2):]

    SOURCE_FILE.write_text(new_content, encoding="utf-8")


def run_command(command, cwd):
    return subprocess.run(
        command,
        cwd=str(cwd),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )


def build_project(progress_message):
    clean = run_command(["make", "clean"], BASE_DIR)
    if clean.returncode != 0:
        raise RuntimeError("make clean thất bại:\n" + clean.stdout[-2500:])

    process = subprocess.Popen(
        ["make"],
        cwd=str(BASE_DIR),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    output_lines = []
    while True:
        line = process.stdout.readline() if process.stdout else ""
        if line:
            output_lines.append(line.rstrip())
            if len(output_lines) > 120:
                output_lines.pop(0)
        elif process.poll() is not None:
            break

    return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(
            "make thất bại (exit code %s):\n%s"
            % (return_code, "\n".join(output_lines[-35:]))
        )


def find_dylib():
    candidates = sorted(
        (BASE_DIR / ".theos" / "obj" / "debug").glob("*.dylib")
    )
    if not candidates:
        candidates = sorted(BASE_DIR.rglob("*.dylib"))
    if not candidates:
        raise FileNotFoundError("Build xong nhưng không tìm thấy file .dylib.")
    return candidates[0]


def main_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("🔨 Build FPS", callback_data="help_fps"),
        types.InlineKeyboardButton("📊 Trạng thái", callback_data="status"),
    )
    kb.add(types.InlineKeyboardButton("ℹ️ Hướng dẫn", callback_data="help"))
    return kb


@bot.message_handler(commands=["start"])
def start(message):
    if not is_admin(message):
        deny(message)
        return
    bot.send_message(
        message.chat.id,
        "✨ <b>N-TRUNG MAKE FPS</b>\n\n"
        "🛠 <b>Theos Build Center</b>\n"
        "⚡ Build FPSDisplay → .dylib\n"
        "🔐 Admin: <code>@vantrung23128</code>\n\n"
        "Dùng <code>/fps TênFPS</code> để build.",
        reply_markup=main_keyboard(),
    )


@bot.message_handler(commands=["help"])
def help_cmd(message):
    if not is_admin(message):
        deny(message)
        return
    bot.reply_to(
        message,
        "📚 <b>HƯỚNG DẪN</b>\n\n"
        "🔨 <code>/fps Nguyễn Trung</code> — build FPS\n"
        "📊 <code>/status</code> — kiểm tra project\n"
        "ℹ️ <code>/help</code> — xem trợ giúp\n\n"
        "Bot sẽ tự backup và khôi phục <code>FPSDisplay.m</code> sau build.",
    )


@bot.message_handler(commands=["status"])
def status(message):
    if not is_admin(message):
        deny(message)
        return
    project_ok = SOURCE_FILE.is_file() and MAKEFILE.is_file()
    theos = os.getenv("THEOS", "")
    bot.send_message(
        message.chat.id,
        "📊 <b>PROJECT STATUS</b>\n\n"
        f"📄 FPSDisplay.m: {'✅' if SOURCE_FILE.is_file() else '❌'}\n"
        f"🧰 Makefile: {'✅' if MAKEFILE.is_file() else '❌'}\n"
        f"🧱 THEOS: {'✅ ' + html.escape(theos) if theos else '⚠️ chưa đặt (Makefile có thể tự cấu hình)'}\n"
        f"🚦 Trạng thái: {'🟢 Sẵn sàng' if project_ok else '🔴 Thiếu file'}"
    )


@bot.message_handler(commands=["fps"])
def fps_command(message):
    if not is_admin(message):
        deny(message)
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "⚠️ Dùng: <code>/fps Tên FPS</code>")
        return

    try:
        fps_name = safe_fps_name(parts[1])
        project_check()
    except Exception as exc:
        bot.reply_to(message, f"❌ <b>Lỗi kiểm tra:</b> {html.escape(str(exc))}")
        return

    if not build_lock.acquire(blocking=False):
        bot.reply_to(message, "⏳ Đang có một build khác chạy. Vui lòng chờ build hiện tại xong.")
        return

    progress = bot.reply_to(
        message,
        f"🚀 <b>Đang build...</b>\n\n🏷 FPS: <code>{html.escape(fps_name)}</code>\n⏳ Vui lòng chờ...",
    )

    try:
        backup_source()
        modify_source(fps_name)
        build_project(progress)
        dylib = find_dylib()

        with dylib.open("rb") as f:
            bot.send_document(
                message.chat.id,
                f,
                caption=(
                    "✅ <b>BUILD THÀNH CÔNG</b>\n\n"
                    f"🏷 FPS: <code>{html.escape(fps_name)}</code>\n"
                    f"📦 File: <code>{html.escape(dylib.name)}</code>\n"
                    "🛡 Source đã được khôi phục."
                ),
            )
        bot.edit_message_text(
            "🎉 <b>Build hoàn thành 100%</b>\n📦 File .dylib đã được gửi.",
            message.chat.id,
            progress.message_id,
        )
    except Exception as exc:
        bot.edit_message_text(
            "❌ <b>BUILD FAILED</b>\n\n<pre>"
            + html.escape(str(exc))[-3500:]
            + "</pre>",
            message.chat.id,
            progress.message_id,
        )
    finally:
        try:
            restore_source()
        finally:
            build_lock.release()


@bot.callback_query_handler(func=lambda call: True)
def callbacks(call):
    if not is_admin(call.message):
        bot.answer_callback_query(call.id, "Không có quyền", show_alert=True)
        return

    if call.data == "help_fps":
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "🔨 Dùng: <code>/fps TênFPS</code>")
    elif call.data == "status":
        bot.answer_callback_query(call.id)
        status(call.message)
    elif call.data == "help":
        bot.answer_callback_query(call.id)
        help_cmd(call.message)


if __name__ == "__main__":
    print("N-TRUNG MAKE FPS bot đang chạy...")
    bot.infinity_polling(skip_pending=True, allowed_updates=["message", "callback_query"])
