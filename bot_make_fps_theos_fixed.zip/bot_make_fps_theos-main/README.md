# N-TRUNG MAKE FPS

Telegram bot hỗ trợ build project FPS bằng Theos.

## Admin

- `@vantrung23128`

## Cài đặt

```bash
python3 -m pip install -r requirements.txt
export BOT_TOKEN='TOKEN_MOI_CUA_BAN'
export ADMIN_USERNAMES='vantrung23128'
python3 main.py
```

Không đặt bot token trực tiếp trong `main.py`.

## Lệnh

- `/start` — menu chính
- `/fps TenFPS` — build
- `/status` — kiểm tra project
- `/help` — trợ giúp

Bot tự xác định thư mục project từ vị trí `main.py`, không sử dụng đường dẫn `/mnt/e/...` cố định.

Trước build, bot backup `FPSDisplay.m`; sau build hoặc khi có lỗi, bot cố gắng khôi phục file nguồn.
